'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Play,
  Square,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Clock,
  Shield,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Activity,
  Zap,
  Target,
  Menu,
  X,
  ChevronRight,
} from 'lucide-react';

interface Position {
  id: string;
  market_id: string;
  question: string;
  strategy: 'reversal' | 'convergence';
  outcome_name: string;
  entry_price: number;
  current_price: number;
  position_size: number;
  entry_time: string;
  current_pnl: number;
  current_pnl_percent: number;
  highest_price: number;
  status: 'open' | 'closed';
  exit_price?: number;
  exit_time?: string;
  exit_reason?: string;
  pnl?: number;
  pnl_percent?: number;
}

interface Statistics {
  isRunning: boolean;
  isInitializing: boolean;
  lastUpdate: string;
  positions: {
    openCount: number;
    closedCount: number;
    openPositions: Position[];
    closedPositions: Position[];
    totalPnl: number;
    floatingPnl: number;
    equity: number;
    totalAssets: number;
    winCount: number;
    lossCount: number;
    winRate: number;
  };
  candidates: {
    totalCandidates: number;
    validCandidates: number;
  };
  config: any;
}


// 侧边栏菜单项
const sidebarItems = [
  { id: 'overview', label: 'Overview', icon: Activity, path: '/' },
  { id: 'live-trading', label: 'Live Trading', icon: Target, path: '/live-trading-v2' },
  { id: 'backtest', label: 'Backtest', icon: TrendingUp, path: '/backtest' },
  { id: 'dashboard', label: 'Dashboard', icon: Zap, path: '/dashboard' },
];

// 动画配置
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.4, 0, 0.2, 1],
    },
  },
};

export default function LiveTradingV2Page() {
  const [activeItem, setActiveItem] = useState('live-trading');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [status, setStatus] = useState<Statistics | null>(null);
  const [loading, setLoading] = useState(false);
  const [starting, setStarting] = useState(false);
  const [stopping, setStopping] = useState(false);
  const [testMode, setTestMode] = useState<string>('all-reversal');
  const [initialCapital, setInitialCapital] = useState<number>(10000);
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [progressText, setProgressText] = useState<string>('');
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Fetch status
  const fetchStatus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/live-trading?version=v2', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(10000),
      });

      const result = await response.json();

      if (result.success) {
        setStatus(result.data);
        setLastUpdateTime(new Date());
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('Failed to fetch status:', err);
      setError(err instanceof Error ? err.message : 'Network request failed');
    } finally {
      setLoading(false);
    }
  }, []);

  // Start trading
  const startTrading = async () => {
    setStarting(true);
    setError(null);
    setProgress(0);
    setProgressText('Initializing...');

    try {
      const progressSteps = [
        { progress: 20, text: 'Clearing old data...' },
        { progress: 40, text: 'Creating trading engine...' },
        { progress: 60, text: 'Connecting to Gamma API...' },
        { progress: 80, text: 'Connecting to CLOB API...' },
        { progress: 100, text: 'Started!' },
      ];

      let stepIndex = 0;
      const progressInterval = setInterval(() => {
        if (stepIndex < progressSteps.length) {
          setProgress(progressSteps[stepIndex].progress);
          setProgressText(progressSteps[stepIndex].text);
          stepIndex++;
        }
      }, 500);

      const response = await fetch('/api/live-trading?version=v2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testMode, initialCapital, version: 'v2' }),
      });

      clearInterval(progressInterval);

      const result = await response.json();

      if (result.success) {
        setStatus(result.data);
        setLastUpdateTime(new Date());
        setTimeout(() => {
          fetchStatus();
          setProgress(0);
          setProgressText('');
        }, 3000);
      } else {
        setError(result.message);
        setProgress(0);
        setProgressText('');
      }
    } catch (err) {
      console.error('Failed to start:', err);
      setError(err instanceof Error ? err.message : 'Start failed');
      setProgress(0);
      setProgressText('');
    } finally {
      setStarting(false);
    }
  };

  // Stop trading
  const stopTrading = async () => {
    setStopping(true);
    setError(null);

    try {
      const response = await fetch('/api/live-trading?version=v2', {
        method: 'DELETE',
      });

      const result = await response.json();

      if (result.success) {
        setStatus(result.data);
        setLastUpdateTime(new Date());
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('Failed to stop:', err);
      setError(err instanceof Error ? err.message : 'Stop failed');
    } finally {
      setStopping(false);
    }
  };

  // Auto refresh
  useEffect(() => {
    if (status?.isRunning) {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }

      refreshIntervalRef.current = setInterval(() => {
        fetchStatus();
      }, 10000);

      return () => {
        if (refreshIntervalRef.current) {
          clearInterval(refreshIntervalRef.current);
        }
      };
    }
  }, [status?.isRunning, fetchStatus]);

  // Initial load
  useEffect(() => {
    fetchStatus();
    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, [fetchStatus]);

  // Calculate total P&L
  const calculateTotalPnl = () => {
    if (!status) return 0;
    return status.positions.totalPnl + status.positions.floatingPnl;
  };

  let totalPnl = calculateTotalPnl();
  let totalPnlPercent = status
    ? ((totalPnl / (initialCapital || 10000)) * 100)
    : 0;

  // Get strategy description
  const getStrategyDescription = (strategy: string) => {
    switch (strategy) {
      case 'reversal':
        return 'Reversal: Capture sudden upside from low prices (1%-35%)';
      case 'convergence':
        return 'Convergence: Price converges to final result near market end';
      default:
        return strategy;
    }
  };

  const getStrategyName = (strategy: string) => {
    switch (strategy) {
      case 'reversal':
        return 'Reversal';
      case 'convergence':
        return 'Convergence';
      default:
        return strategy;
    }
  };
  
  const getStrategyColor = (strategy: string) => {
    switch (strategy) {
      case 'convergence':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'arbitrage':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'reversal':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  totalPnl = calculateTotalPnl();
  totalPnlPercent = status
    ? ((totalPnl / (initialCapital || 10000)) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-slate-100">
      {/* 侧边栏 */}
      <motion.aside
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="fixed left-0 top-0 z-50 hidden h-screen w-[200px] border-r border-slate-800/50 bg-[#0F172A]/95 backdrop-blur-sm lg:block"
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="border-b border-slate-800/50 p-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#06B6D4] to-[#8B5CF6] shadow-lg shadow-[#06B6D4]/20">
                <Activity className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-sm text-white">Polymarket</h1>
                <p className="text-[9px] text-slate-400">Arbitrage System</p>
              </div>
            </div>
          </div>

          {/* 导航菜单 */}
          <nav className="flex-1 overflow-y-auto px-3 py-2">
            <ul className="space-y-0.5">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeItem === item.id;

                return (
                  <li key={item.id}>
                    <Link
                      href={item.path}
                      onClick={() => setActiveItem(item.id)}
                      className={`relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-all duration-300 ${
                        isActive
                          ? 'bg-[#1E293B] text-[#06B6D4] shadow-lg shadow-[#06B6D4]/10'
                          : 'text-slate-400 hover:bg-[#1E293B]/50 hover:text-slate-100'
                      }`}
                    >
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="absolute left-0 h-6 w-0.5 rounded-r-full bg-[#06B6D4]"
                          initial={false}
                          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                        />
                      )}
                      <Icon className="h-4 w-4" />
                      <span className="font-medium">{item.label}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* 底部状态 */}
          <div className="border-t border-slate-800/50 p-3">
            <div className="flex items-center gap-2 rounded-lg bg-[#1E293B]/30 px-3 py-2">
              <div className="flex h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse" />
              <div className="flex-1">
                <p className="text-[9px] text-slate-400">Status</p>
                <p className="text-[10px] font-medium text-[#10B981]">Live</p>
              </div>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* 移动端顶部栏 */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 border-b border-slate-800/50 bg-[#0F172A]/95 backdrop-blur-sm">
        <div className="flex items-center justify-between px-4 py-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={toggleMobileMenu}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-[#1E293B]/50 hover:text-slate-100"
            >
              {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-[#06B6D4] to-[#8B5CF6]">
                <Activity className="h-3.5 w-3.5 text-white" />
              </div>
              <span className="font-bold text-sm text-white">Live Trading</span>
            </div>
          </div>
          <div className="flex h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse" />
        </div>

        {/* 移动端菜单 */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="border-t border-slate-800/50 bg-[#0F172A] px-4 py-2"
            >
              <ul className="space-y-0.5">
                {sidebarItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeItem === item.id;

                  return (
                    <li key={item.id}>
                      <Link
                        href={item.path}
                        onClick={() => {
                          setActiveItem(item.id);
                          setIsMobileMenuOpen(false);
                        }}
                        className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-all duration-300 ${
                          isActive
                            ? 'bg-[#1E293B] text-[#06B6D4]'
                            : 'text-slate-400 hover:bg-[#1E293B]/50 hover:text-slate-100'
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                        <span className="font-medium">{item.label}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 主内容区 */}
      <main className="lg:ml-[200px] min-h-screen">
        {/* 顶部栏 */}
        <div className="hidden lg:flex items-center justify-between border-b border-slate-800/50 bg-[#0F172A]/95 backdrop-blur-sm px-6 py-3">
          <div>
            <h2 className="text-lg font-bold text-white">Live Trading</h2>
            <p className="text-xs text-slate-400">Real-time automated trading with live market data</p>
          </div>
          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="rounded-lg border border-slate-700/50 bg-[#1E293B]/50 px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:bg-[#2D3F57]"
            >
              <span className="flex items-center gap-2">
                <Clock className="h-3.5 w-3.5" />
                {lastUpdateTime ? `Updated: ${lastUpdateTime.toLocaleTimeString()}` : 'Last updated: 2 min ago'}
              </span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={fetchStatus}
              disabled={loading}
              className="rounded-lg border border-slate-700/50 bg-[#1E293B]/50 px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:bg-[#2D3F57]"
            >
              <span className="flex items-center gap-2">
                <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </span>
            </motion.button>
          </div>
        </div>

        {/* 内容区域 */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="p-4 lg:p-8 pt-20 lg:pt-8"
        >
            <div className="ml-0 flex items-center gap-4">
                {status?.isInitializing ? (
                  <Badge className="bg-yellow-500/20 text-yellow-500 text-[10px] px-2 py-0.5">
                    <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                    Initializing
                  </Badge>
                ) : status?.isRunning ? (
                  <Badge className="bg-[#10B981]/20 text-[#10B981] text-[10px] px-2 py-0.5">
                    <div className="mr-1 h-2 w-2 animate-pulse rounded-full bg-[#10B981]"></div>
                    Running
                  </Badge>
                ) : (
                  <Badge className="bg-slate-800/50 text-slate-400 text-[10px] px-2 py-0.5">
                    Stopped
                  </Badge>
                )}
                {lastUpdateTime && (
                  <span className="text-[10px] text-slate-500 w-150">
                    Last update: {lastUpdateTime.toLocaleTimeString()}
                  </span>
                )}
                
                <Button variant="outline" size="sm" onClick={fetchStatus} disabled={loading} className="h-7 px-2 text-[10px] ml-170 bg-[#1E293B]">
                  {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                </Button>
                {!status?.isRunning ? (
                  <Button size="sm" onClick={startTrading} disabled={starting || status?.isRunning} className="bg-[#06B6D4] hover:bg-[#0891B2] text-white h-7 px-3 text-[10px]">
                    {starting ? (
                      <>
                        <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                        Starting...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-3 w-3" />
                        Start
                      </>
                    )}
                  </Button>
                ) : (
                  <Button variant="destructive" size="sm" onClick={stopTrading} disabled={stopping} className="h-7 px-3 text-[10px]">
                    {stopping ? (
                      <>
                        <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                        Stopping...
                      </>
                    ) : (
                      <>
                        <Square className="mr-2 h-3 w-3" />
                        Stop
                      </>
                    )}
                  </Button>
                )}
              </div>
              
        </motion.div>

        {/* Page Content */}
        <div className="p-4">
          {/* Error Alert */}
          {error && (
            <Alert variant="destructive" className="mb-4 bg-red-900/20 border-red-800/50">
              <AlertCircle className="h-3 w-3" />
              <AlertTitle className="text-xs">Error</AlertTitle>
              <AlertDescription className="text-[10px]">{error}</AlertDescription>
            </Alert>
          )}

          {/* Progress */}
          {progress > 0 && (
            <Card className="mb-4 border-[#06B6D4]/50 bg-[#06B6D4]/10">
              <CardContent className="p-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[10px] text-[#06B6D4]">
                    <span>{progressText}</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-1.5" />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Configuration Panel */}
          {!status?.isRunning && (
            <Card className="mb-4 bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2 text-slate-400">
                  <Target className="h-4 w-4 text-slate-200" />
                  Trading Configuration
                </CardTitle>
                <CardDescription className="text-[10px] text-slate-400">Configure trading mode and initial capital</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-400">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-medium text-slate-300">Test Mode</label>
                    <Select value={testMode} onValueChange={setTestMode}>
                      <SelectTrigger className="h-8 text-[10px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all-reversal" className="text-[10px]">
                          All Reversal (5 positions)
                        </SelectItem>
                        <SelectItem value="1-convergence-4-reversal" className="text-[10px]">
                          1 Convergence + 4 Reversal
                        </SelectItem>
                        <SelectItem value="2-convergence-3-reversal" className="text-[10px]">
                          2 Convergence + 3 Reversal
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-medium text-slate-300">Initial Capital (USD)</label>
                    <Input
                      type="number"
                      value={initialCapital}
                      onChange={(e) => setInitialCapital(Number(e.target.value))}
                      className="h-8 text-[10px]"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats Grid */}
          {status && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-4">
              <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                <CardHeader className="pb-1">
                  <CardDescription className="text-[12px] text-slate-400">Status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {status.isInitializing ? (
                      <Loader2 className="h-5 w-5 text-yellow-500 animate-spin" />
                    ) : status.isRunning ? (
                      <CheckCircle2 className="h-5 w-5 text-[#10B981]" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-yellow-500" />
                    )}
                    <span className="text-sm font-bold text-white">
                      {status.isInitializing ? 'Initializing' : status.isRunning ? 'Running' : 'Stopped'}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                <CardHeader className="pb-1">
                  <CardDescription className="text-[12px] text-slate-400">Positions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-[#06B6D4]" />
                    <span className="text-sm font-bold text-white">
                      {status.positions.openCount}/{status.config?.maxPositions || 5}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Closed: {status.positions.closedCount}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                <CardHeader className="pb-1">
                  <CardDescription className="text-[12px] text-slate-400">Total P&L</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {totalPnl >= 0 ? (
                      <TrendingUp className="h-5 w-5 text-[#10B981]" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-red-400" />
                    )}
                    <span className={`text-sm font-bold ${totalPnl >= 0 ? 'text-[#10B981]' : 'text-red-400'}`}>
                      ${totalPnl.toFixed(2)}
                    </span>
                  </div>
                  <p className={`text-[10px] mt-1 ${totalPnl >= 0 ? 'text-[#10B981]' : 'text-red-400'}`}>
                    {totalPnlPercent >= 0 ? '+' : ''}{totalPnlPercent.toFixed(2)}%
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                <CardHeader className="pb-1">
                  <CardDescription className="text-[12px] text-slate-400">Candidates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-[#8B5CF6]" />
                    <span className="text-sm font-bold text-white">
                      {status.candidates.totalCandidates}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Total: {status.candidates.totalCandidates}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Positions Tabs */}
          {status && (
            <Tabs defaultValue="open" className="space-y-4">
              <TabsList className="bg-[#1E293B]/40 border border-slate-800/50">
                <TabsTrigger value="open" className="text-[10px] text-slate-400 data-[state=active]:bg-[#06B6D4]/20 data-[state=active]:text-[#06B6D4]">
                  Open Positions ({status.positions.openCount})
                </TabsTrigger>
                <TabsTrigger value="closed" className="text-[10px] text-slate-400 data-[state=active]:bg-[#06B6D4]/20 data-[state=active]:text-[#06B6D4]">
                  Closed ({status.positions.closedCount})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="open">
                <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2 text-slate-300">
                      <Zap className="h-4 w-4" />
                      Open Positions
                    </CardTitle>
                    {status.positions.openCount === 0 && (
                      <CardDescription className="text-[10px] text-slate-400">No positions, system looking for opportunities...</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    {status.positions.openPositions.length === 0 ? (
                      <div className="text-center py-8 text-slate-400">
                        <Clock className="h-10 w-10 mx-auto mb-3 opacity-50" />
                        <p className="text-[10px]">No positions</p>
                        <p className="text-[9px] mt-2">System fetching market data from Gamma API...</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-800/50">
                            <TableHead className="text-[12px] text-slate-200">Market</TableHead>
                            <TableHead className="text-[12px] text-slate-200">Strategy</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">Entry</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">Current</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">Size</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">P&L</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">P&L %</TableHead>
                            <TableHead className="text-[12px] text-slate-200">Entry Time</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {status.positions.openPositions.map((position) => (
                            <TableRow key={position.id} className="border-slate-800/50">
                              <TableCell className="text-white text-[10px]">
                                <div className="max-w-xs truncate" title={position.question}>
                                  {position.question}
                                </div>
                              </TableCell>
                              <TableCell className="text-[10px]">
                                <Badge variant="outline" className={`${getStrategyColor(position.strategy)} text-[9px] px-2 py-0.5`}>
                                  {getStrategyName(position.strategy)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-white text-[10px] text-right">
                                ${(position.entry_price * 100).toFixed(2)}%
                              </TableCell>
                              <TableCell className="text-white text-[10px] text-right">
                                ${(position.current_price * 100).toFixed(2)}%
                              </TableCell>
                              <TableCell className="text-white text-[10px] text-right">
                                {position.position_size.toFixed(2)}
                              </TableCell>
                              <TableCell className={`${(position.current_pnl >= 0) ? 'text-[#10B981]' : 'text-red-400'} text-[10px] text-right`}>
                                ${position.current_pnl.toFixed(2)}
                              </TableCell>
                              <TableCell className={`${(position.current_pnl_percent >= 0) ? 'text-[#10B981]' : 'text-red-400'} text-[10px] text-right`}>
                                {position.current_pnl_percent >= 0 ? '+' : ''}{position.current_pnl_percent.toFixed(2)}%
                              </TableCell>
                              <TableCell className="text-slate-400 text-[10px]">
                                {new Date(position.entry_time).toLocaleString()}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="closed">
                <Card className="bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2 text-slate-300">
                      <Shield className="h-4 w-4 text-slate-300" />
                      Closed Positions
                    </CardTitle>
                    {status.positions.closedCount === 0 && (
                      <CardDescription className="text-[10px] text-slate-400">No closed positions yet...</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    {status.positions.closedPositions.length === 0 ? (
                      <div className="text-center py-8 text-slate-400">
                        <AlertCircle className="h-10 w-10 mx-auto mb-3 opacity-50" />
                        <p className="text-[10px]">No closed positions</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-800/50">
                            <TableHead className="text-[12px] text-slate-200">Market</TableHead>
                            <TableHead className="text-[12px] text-slate-200">Strategy</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">Entry</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">Exit</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">P&L</TableHead>
                            <TableHead className="text-[12px] text-right text-slate-200">P&L %</TableHead>
                            <TableHead className="text-[12px] text-slate-200">Reason</TableHead>
                            <TableHead className="text-[12px] text-slate-200">Exit Time</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {status.positions.closedPositions.map((position) => (
                            <TableRow key={position.id} className="border-slate-800/50">
                              <TableCell className="text-white text-[10px]">
                                <div className="max-w-xs truncate" title={position.question}>
                                  {position.question}
                                </div>
                              </TableCell>
                              <TableCell className="text-[10px]">
                                <Badge variant="outline" className={`${getStrategyColor(position.strategy)} text-[9px] px-2 py-0.5`}>
                                  {getStrategyName(position.strategy)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-white text-[10px] text-right">
                                ${(position.entry_price * 100).toFixed(2)}%
                              </TableCell>
                              <TableCell className="text-white text-[10px] text-right">
                                ${((position.exit_price || 0) * 100).toFixed(2)}%
                              </TableCell>
                              <TableCell className={`${(position.pnl || 0) >= 0 ? 'text-[#10B981]' : 'text-red-400'} text-[10px] text-right`}>
                                ${(position.pnl || 0).toFixed(2)}
                              </TableCell>
                              <TableCell className={`${(position.pnl_percent || 0) >= 0 ? 'text-[#10B981]' : 'text-red-400'} text-[10px] text-right`}>
                                {(position.pnl_percent || 0) >= 0 ? '+' : ''}{(position.pnl_percent || 0).toFixed(2)}%
                              </TableCell>
                              <TableCell className="text-[10px]">
                                <Badge variant="outline" className="text-[9px] px-2 py-0.5">
                                  {position.exit_reason || 'Unknown'}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-slate-400 text-[10px]">
                                {position.exit_time ? new Date(position.exit_time).toLocaleString() : '-'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}

          {/* System Info */}
          {status && (
            <Card className="mt-4 bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2 text-slate-300">
                  <Activity className="h-4 w-4 text-slate-300" />
                  System Info
                </CardTitle>
                <CardDescription className="text-[10px] text-slate-400">Real-time system status and statistics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Total Assets</span>
                      <span className="text-white font-bold">${status.positions.totalAssets.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Equity</span>
                      <span className="text-white font-bold">${status.positions.equity.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Win Rate</span>
                      <span className="text-white font-bold">{(status.positions.winRate * 100).toFixed(2)}%</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Win/Loss</span>
                      <span className="text-white font-bold">{status.positions.winCount}/{status.positions.lossCount}</span>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Floating P&L</span>
                      <span className={`${(status.positions.floatingPnl >= 0) ? 'text-[#10B981]' : 'text-red-400'} font-bold`}>
                        ${status.positions.floatingPnl.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Realized P&L</span>
                      <span className={`${(status.positions.totalPnl >= 0) ? 'text-[#10B981]' : 'text-red-400'} font-bold`}>
                        ${status.positions.totalPnl.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Strategy Descriptions */}
          <Card className="mt-4 bg-[#1E293B]/40 backdrop-blur-xl border-slate-800/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-slate-300">
                <Target className="h-4 w-4 text-slate-300" />
                Strategy Descriptions
              </CardTitle>
              <CardDescription className="text-[10px] text-slate-400">Current trading strategies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-start gap-2 p-2.5 rounded-lg bg-[#0F172A]/50 border border-slate-800/50">
                  <Badge variant="outline" className="bg-purple-500/20 text-purple-400 text-[9px] px-2 py-0.5">Reversal</Badge>
                  <div>
                    <p className="text-white font-medium text-[10px]">Reversal Strategy</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{getStrategyDescription('reversal')}</p>
                    <p className="text-[9px] text-slate-500 mt-0.5">Price range: 1%-5%, 5%-10%, 10%-20%, 20%-35%</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 p-2.5 rounded-lg bg-[#0F172A]/50 border border-slate-800/50">
                  <Badge variant="outline" className="bg-blue-500/20 text-blue-400 text-[9px] px-2 py-0.5">Convergence</Badge>
                  <div>
                    <p className="text-white font-medium text-[10px]">Convergence Strategy</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{getStrategyDescription('convergence')}</p>
                    <p className="text-[9px] text-slate-500 mt-0.5">Price range: 90%-95%, within 48h of end</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
